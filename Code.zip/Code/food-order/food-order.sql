-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2021 at 01:24 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food-order`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(13, 'Mayank Prajapati', 'Moon', 'e9bd7d965e5a14fcff37f26517f720eb'),
(14, 'Prajna Mohapatra', 'IOW', 'fe590a02423c17ceb87876f77cb4b001');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(4, 'Pizza', 'Food_Category_790.jpg', 'Yes', 'Yes'),
(5, 'Burger', 'Food_Category_344.jpg', 'Yes', 'Yes'),
(6, 'MoMo', 'Food_Category_77.jpg', 'Yes', 'Yes'),
(9, 'Chicken Wings', 'Food_Category_511.png', 'Yes', 'Yes'),
(10, 'Pasta', 'Food_Category_324.png', 'Yes', 'Yes'),
(11, 'Soup', 'Food_Category_797.png', 'Yes', 'Yes'),
(12, 'Sandwich', 'Food_Category_289.png', 'Yes', 'Yes'),
(13, 'Salads', 'Food_Category_532.png', 'Yes', 'Yes'),
(14, 'Cakes', 'Food_Category_245.png', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(9, 'Pan-fried Momo', 'Fried momos sautéed with a spicy, aromatic and crunchy filling of crisp veggies flavoured with garlic.', '240.00', 'Food-Name-3193.png', 6, 'Yes', 'Yes'),
(11, 'Chicken Extravaganza', 'Made with Italian Sauce,Chicken,Black Olives,Onions,Fresh Tomatoes,Jalapenos & Extra Cheese.', '299.00', 'Food-Name-6971.png', 9, 'Yes', 'Yes'),
(12, 'Smoky Burger', 'Juicy chicken patty topped with onion,fresh lettuce,cheese,smoky barbeque sauce,all nestled in a double split artisan bun.', '270.00', 'Food-Name-3432.png', 5, 'Yes', 'Yes'),
(13, 'Cheese BBQ Chicken Pizza', 'Made with Barbeque chicken,Onion,Fresh Tomatoes,Red Paprika & Exotic Herbs.', '349.00', 'Food-Name-4440.png', 4, 'Yes', 'Yes'),
(14, 'Hawaiian Burger', 'Chicken patty, Grilled pineapple, cheese, Lettuce, Onions, Mayo and BBQ Sauce.', '350.00', 'Food-Name-7617.png', 5, 'Yes', 'Yes'),
(15, 'Chicken Schezwan Momo', 'Chicken momos tossed with sautéed vegetables, spring onions and with spicy schezwan sauce.', '250.00', 'Food-Name-7669.png', 6, 'Yes', 'Yes'),
(16, 'Baked Pasta', 'Baked pasta loaded with Onion, Grape Tomatoes, Zucchini, Mushroom, Broccoli, Red & Yellow Pepper.', '270.00', 'Food-Name-3465.png', 10, 'Yes', 'Yes'),
(17, 'White Sauce Pasta', 'Rich, creamy & saucy pasta, perfectly seasoned with Italian herbs and topped with red chilli flakes.', '250.00', 'Food-Name-161.png', 4, 'Yes', 'Yes'),
(18, 'Creamy Tomato', 'Rich, creamy tomato soup with spring onions, basil and exotic flavours.', '280.00', 'Food-Name-9862.png', 11, 'Yes', 'Yes'),
(19, 'Cream of Mushroom', 'Rich mushroom soup made with fresh cream and button mushrooms', '280.00', 'Food-Name-2412.png', 11, 'Yes', 'Yes'),
(20, 'Chicken Fillet', 'Skewed chicken in special BBQ sauce, mayonaise and lettuce.', '300.00', 'Food-Name-6958.png', 9, 'Yes', 'Yes'),
(21, 'Country Tuna', 'Tuna mixed with mayonnaise,chopped veggies and black olives.', '350.00', 'Food-Name-6560.png', 5, 'Yes', 'Yes'),
(22, 'Greenhouse', 'Chicken or Tofu with green noodles,avocado,carrot,cashews,black sesame & coconut soy dressing', '270.00', 'Food-Name-9887.png', 9, 'Yes', 'Yes'),
(23, 'King of House', 'Poached king prawns,rice noodles,pineapple,carrot,sprouts,cashews, shallot & chilli jam lemon dressing', '350.00', 'Food-Name-1814.png', 10, 'Yes', 'Yes'),
(24, 'Mississippi Mud Cake', 'Extra rich, dense, moist, thick creamy pastry with white chocolate mousse.', '290.00', 'Food-Name-5362.png', 14, 'Yes', 'Yes'),
(25, 'Oreo Madness', 'Oreo cookies sandwiched with vanilla icecream,choco-caramel sauce', '380.00', 'Food-Name-9092.png', 14, 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `food`, `price`, `qty`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(4, 'Pan-fried Momo', '240.00', 1, '240.00', '2021-05-03 11:02:29', 'Delivered', 'Mayank Prajapati ', '8873212926', 'hello@moon.com', 'Qn 606 Street 21, Sector 9 D \r\nBokaro Steel City, Jharkhand (827009)'),
(5, 'Mississippi Mud Cake', '290.00', 1, '290.00', '2021-05-03 11:16:59', 'Delivered', 'Jyoti Prajapati', '80128190471', 'hello@light.com', 'Eg 98 , Patel Nagar New Delhi 110012'),
(6, 'Chicken Fillet', '300.00', 1, '300.00', '2021-05-04 12:54:36', 'Delivered', 'Raj Ranjan ', '828869681786', 'raj@raj.com', 'Jainamore, Main Market Jainamore '),
(7, 'Greenhouse', '270.00', 1, '270.00', '2021-05-04 01:21:07', 'Delivered', 'PPM ', '8926832698', 'hjdgg@joh.com', 'Kuch bhi ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
